/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Schedule DAO
 */
package dao;

import entity.Schedule;
import java.util.List;

/**
 * The class list method select information from Schedule table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting data
 * @author Tô Huyền Diệu
 */
public interface ScheduleDAO {
    
    /**
     * Select the Schedule. All Schedule will be returned
     * The result contains a list of <code>Schedule</code> with day and time
     * 
     * @return a list of <code>Schedule</code>. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    public List<Schedule> getAllSchedule() throws Exception;
}
