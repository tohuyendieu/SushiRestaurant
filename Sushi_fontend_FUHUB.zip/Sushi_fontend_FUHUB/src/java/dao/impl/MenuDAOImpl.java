/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       MenuDAO Implement and extends DBContext
 */
package dao.impl;

import context.DBContext;
import dao.MenuDAO;
import entity.Menu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * The class contains method select information from Menu table in database.
 * The method will throw an object of <code> java.lang.SQLException</code> class 
 * if there is any error occurring when selecting data
 * @author Tô Huyền Diệu
 */
public class MenuDAOImpl extends DBContext implements MenuDAO{

    /**
     * Constructor
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public MenuDAOImpl() throws ClassNotFoundException, SQLException {
    }

    /**
     * Select the Menu that has order from pageIndex*pageSize to pageIndex*pageSize+pageSize
     * The result contain a list of <code>Menu</code> with id, title, img, content, price and detail.
     * 
     * @param pageIndex the order of page will display the Menu. It is a <code>int</code> data type
     * @param pageSize the size of page. It is a <code>int</code> data type
     * @return a list of <code>Menu</code>. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    @Override
    public List<Menu> getListMenu(int pageIndex, int pageSize) throws Exception {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        List<Menu> list = new ArrayList<>();
        try {
            String query = "SELECT*\n"
                    + "FROM (\n"
                    + "		select ROW_NUMBER() over (order by ID asc) as rowNumber, *\n"
                    + "		from Menu\n"
                    + "	) as x\n"
                    + "WHERE rowNumber between (?-1)*?+1 and ?*? ";
            this.connection = getConnection();
            statement = this.connection.prepareStatement(query);
            statement.setInt(1, pageIndex);
            statement.setInt(2, pageSize);
            statement.setInt(3, pageIndex);
            statement.setInt(4, pageSize);
            result = statement.executeQuery();
            while(result.next()){
                list.add(new Menu(result.getInt("id"),
                        result.getString("title"),
                        result.getString("img"),
                        result.getString("content"), 
                        result.getFloat("price"), 
                        result.getString("detail")));
            }
            return list;
        } catch (SQLException e) {
            throw e;
        } finally{
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(this.connection);
        }
    }
    
    /**
     * Select amount of Menu
     * The result contain a number<code>int</code> 
     * 
     * @return a number. It is a <code>int</code> datatype
     * @throws Exception 
     */
    @Override
    public int amountOfMenu() throws Exception{
        int amount = 0;
        String query = "SELECT COUNT(id) FROM Menu";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            this.connection = getConnection();
            statement = this.connection.prepareStatement(query);
            result = statement.executeQuery();
            if(result.next()) return (result.getInt(1));
        } catch (SQLException e) {
            throw e;
        } finally{
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(this.connection);
        }
        return amount;
    }
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException, Exception {
        List<Menu> list = new MenuDAOImpl().getListMenu(1,3);
        for (Menu menu : list) {
            System.out.println(menu.toString());
        }
    }
}
