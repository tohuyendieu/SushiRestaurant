/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Information DAO Implement and extends DBContext
 */
package dao.impl;

import context.DBContext;
import entity.Infor;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import dao.InforDAO;
import java.sql.Connection;

/**
 * The class contains method select, update information from Infor table in
 * database. The method will throw an object of
 * <code> java.lang.Exception</code> class if there is any error occurring when
 * selecting data or updating
 *
 * @author Tô Huyền Diệu
 */
public class InforDAOImpl extends DBContext implements InforDAO {

    /**
     * Constructor InforDAOImpl
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public InforDAOImpl() throws ClassNotFoundException, SQLException {
    }

    /**
     * Select the Infor. All the information of restaurant will be return 
     * The result contain a <code>Infor</code> object with address, tel, email
     *
     * @return <code>Infor</code> object. It is <code>entity.Infor</code> object
     * @throws Exception
     */
    @Override
    public Infor getAllInfor() throws Exception {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        String query = "SELECT [address], tel, email\n"
                + "FROM Infor";
        try {
            this.connection = getConnection();
            statement = this.connection.prepareStatement(query);
            result = statement.executeQuery();
            while (result.next()) {
                return (new Infor(result.getString(1),
                        result.getString(2),
                        result.getString(3)));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(this.connection);
        }
        return null;
    }

    /**
     * Select the views of page. Amount of view will be return The result is a <code>int<code> data type.
     *
     * @return a number <code>int</code>. It is a data type
     * @throws Exception
     */
    @Override
    public int getAllViews() throws Exception {
        String query = "SELECT* from [View]";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            this.connection = getConnection();
            statement = this.connection.prepareStatement(query);
            result = statement.executeQuery();
            if (result.next()) {
                return (result.getInt(1));
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(this.connection);
        }
        return 0;
    }

    /**
     * Update the views.
     *
     * @throws Exception
     */
    @Override
    public void updateView() throws Exception{
        String query = "UPDATE [View]\n"
                + "SET [view] = ( (SELECT* from [View] ) +1)";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            this.connection = getConnection();
            statement = this.connection.prepareStatement(query);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw e;
        } finally {
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(this.connection);
        }
    }

    public static void main(String[] args) throws Exception {
        InforDAO dao = new InforDAOImpl();
        System.out.println(dao.getAllViews());
        dao.updateView();
        System.out.println(dao.getAllViews());
    }
}
