/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Schedule DAO Implement and extends DBContext
 */
package dao.impl;

import context.DBContext;
import dao.ScheduleDAO;
import entity.Schedule;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * The class contains method select information from Schedule table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting data
 * @author Tô Huyền Diệu
 */
public class ScheduleDAOImpl extends DBContext implements ScheduleDAO{

    /**
     * Constructor
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public ScheduleDAOImpl() throws ClassNotFoundException, SQLException {
    }

    /**
     * Select the Schedule. All Schedule will be returned
     * The result contains a list of <code>Schedule</code> with day and time
     * 
     * @return a list of <code>Schedule</code>. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    @Override
    public List<Schedule> getAllSchedule() throws Exception {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            String query = "SELECT* FROM Schedule";
            this.connection = getConnection();
            statement = this.connection.prepareStatement(query);
            result = statement.executeQuery();
            List<Schedule> list = new ArrayList<>();
            while (result.next()) {
                list.add(new Schedule(result.getString(1), result.getString(2)));
            }
            return list;
        }catch(ClassNotFoundException | SQLException e){
            throw e;
        }finally{
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(this.connection);
        }

    }

//    public static void main(String[] args) throws ClassNotFoundException, SQLException, Exception {
//        ScheduleDAOImpl sd = new ScheduleDAOImpl();
//        List<Schedule> list = sd.getAllSchedule();
//        for (Schedule schedule : list) {
//            System.out.println(schedule);
//        }
//    }
}
