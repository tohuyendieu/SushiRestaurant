/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Menu DAO 
 */
package dao;

import entity.Menu;
import java.util.List;

/**
 * The class list method select information from Menu table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting data
 * @author Tô Huyền Diệu
 */
public interface MenuDAO {
    
    /**
     * Select the Menu that has order from pageIndex*pageSize to pageIndex*pageSize+pageSize
     * The result contain a list of <code>Menu</code> with id, title, img, content, price and detail.
     * 
     * @param pageIndex the order of page will display the Menu. It is a <code>int</code> data type
     * @param pageSize the size of page. It is a <code>int</code> data type
     * @return a list of <code>Menu</code>. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    public List<Menu> getListMenu(int pageIndex, int pageSize) throws Exception;
    
    /**
     * Select amount of Menu. Amount of Menu will be returned
     * The result contain a number<code>int</code> 
     * 
     * @return a number. It is a <code>int</code> datatype
     * @throws Exception 
     */
    public int amountOfMenu() throws Exception;
}
