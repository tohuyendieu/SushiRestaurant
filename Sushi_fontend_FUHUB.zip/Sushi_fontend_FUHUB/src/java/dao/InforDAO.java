/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Information DAO 
 */
package dao;

import entity.Infor;

/**
 * The class list method select, update information from Infor table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * @author Tô Huyền Diệu
 */
public interface InforDAO {

    /**
     * Select the Infor. All the information of restaurant will be return
     * The result contain a <code>Infor</code> object with address, tel, email
     * 
     * @return <code>Infor</code> object. It is <code>entity.Infor</code> object
     * @throws Exception
     */
    public Infor getAllInfor() throws Exception;
    
    /**
     * Select the views of page. Amount of view will be return
     * The result is a <code>int<code> data type.
     * 
     * @return a number <code>int</code>. It is a data type
     * @throws Exception 
     */
    public int getAllViews() throws Exception;
    
    /**
     * Update the views.
     * 
     * @throws Exception 
     */
    public void updateView() throws Exception;
}
