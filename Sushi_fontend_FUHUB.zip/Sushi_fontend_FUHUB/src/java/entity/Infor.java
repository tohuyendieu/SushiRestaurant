/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Information object
 */
package entity;

/**
 * The class describes the Information object.
 * The class contains method getter, setter, toString and entity of Information object
 * @author Tô Huyền Diệu
 */
public class Infor {
    private String address, tel, email;

    public Infor() {
    }

    public Infor(String address, String tel, String email) {
        this.address = address;
        this.tel = tel;
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Infor{" + "address=" + address + ", tel=" + tel + ", email=" + email + '}';
    }       
}
