/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Menu object
 */
package entity;

/**
 * The class describes the Menu object
 * The class contains method getter, setter and entity of Menu object
 * @author Tô Huyền Diệu
 */
public class Menu {
    private int id;
    private String title, img, content;
    private float price;
    private String detail;

    public Menu() {
    }

    public Menu(int id, String title, String img, String content, float price, String detail) {
        this.id = id;
        this.title = title;
        this.img = img;
        this.content = content;
        this.price = price;
        this.detail = detail;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
    
}
