/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       Schedule object
 */
package entity;

/**
 * The class describes the Schedule object 
 * The class contains method getter, setter and entity of Schedule object
 * @author Tô Huyền Diệu
 */
public class Schedule {
    private String day, time;

    public Schedule() {
    }

    public Schedule(String day, String time) {
        this.day = day;
        this.time = time;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    
}
