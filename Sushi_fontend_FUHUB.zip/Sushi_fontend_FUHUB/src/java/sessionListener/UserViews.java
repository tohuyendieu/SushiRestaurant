/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/22      Tô Huyền Diệu       HttpSessionListener implement 
 */
package sessionListener;

import dao.InforDAO;
import dao.impl.InforDAOImpl;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * The class contains method session created
 * @author Tô Huyền Diệu
 */

public class UserViews implements HttpSessionListener{
    
    /**
     * Select views from database to set attribute in session and update views into database     
     * @param se the HttpSessionEvent
     */
    @Override
    public void sessionCreated(HttpSessionEvent se){
        HttpSession session = se.getSession();
         try {
            InforDAO inforDao = new InforDAOImpl();
            inforDao.updateView();             
            int view = inforDao.getAllViews();               
            session.setAttribute("view", view);
        } catch (Exception e) {
            session.setAttribute("error", e);
        }
    }

    
    /**
     * 
     * @param se the HttpSessionEvent
     */
    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
    }    
}
