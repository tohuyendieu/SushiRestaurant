/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0013/ The Sushi Restaurant
 * 
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/21      Tô Huyền Diệu       SQL Connection
 */
package context;

/**
 * The class contains method connect, close connection to SushiRestaunrant database.
 * The method will throw an object of <code>java.lang.SQLException</code> class 
 * if there is any error occurring when connecting and closing connection to database
 * @author Tô Huyền Diệu
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class DBContext {

    protected Connection connection;

    /**
     * Set connection to SQLServer
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public DBContext() throws ClassNotFoundException, SQLException {
        this.connection = this.getConnection();
    }

    /**
     * Get connection to SQLServer
     * @return a <code>Connection</code> object. It is a <code>java.sql.Connection</code>
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public Connection getConnection() throws ClassNotFoundException, SQLException {
        String url = "jdbc:sqlserver://" + serverName + ":" + portNumber + "\\" + instance + ";databaseName=" + dbName;
        if (instance == null || instance.trim().isEmpty()) {
            url = "jdbc:sqlserver://" + serverName + ":" + portNumber + ";databaseName=" + dbName;
        }
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        return DriverManager.getConnection(url, userID, password);
    }

    /**
     * Close ResultSet
     * @param rs the ResultSet. It is a <code>java.sql.ResultSet</code>
     * @throws SQLException 
     */
    public void closeResusult(ResultSet rs) throws SQLException {
        if (rs != null && !rs.isClosed()) {
            rs.close();
        }
    }

    /**
     * Close PreparedStatement
     * @param ps the PreparedStatement. It is a <code>java.sql.PreparedStatement</code>
     * @throws SQLException 
     */
    public void closePreparedStatement(PreparedStatement ps) throws SQLException {
        if (ps != null && !ps.isClosed()) {
            ps.close();
        }
    }

    /**
     * Close Connection
     * @param con the Connection. It is a <code>java.sql.Connection</code>
     * @throws SQLException 
     */
    public void closeConnection(Connection con) throws SQLException {
        if (con != null && !con.isClosed()) {
            con.close();
        }
    }
    /*Insert your other code right after this comment*/
 /*Change/update information of your database connection, DO NOT change name of instance variables in this class*/
    private final String serverName = "localhost";
    private final String dbName = "SuShiRestaurant";
    private final String portNumber = "1433";
    private final String instance = "";//LEAVE THIS ONE EMPTY IF YOUR SQL IS A SINGLE INSTANCE
    private final String userID = "sa";
    private final String password = "123456";
}