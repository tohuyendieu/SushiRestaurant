CREATE DATABASE SuShiRestaurant
Go
Use SuShiRestaurant
Go
CREATE TABLE Menu(
	id int primary key,
	title varchar(MAX),
	img varchar(MAX),
	content varchar(MAX),
	price float,
	detail varchar(MAX)
)
--drop table menu

INSERT INTO Menu
VALUES
	(1,'24 sushi','images/sushi/sushi1.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.',20.5,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.'),
	(2,'Menu 2','images/sushi/sushi0.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.',20,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.'),
	(3,'Menu 3','images/sushi/sushi2.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.',24,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.')


INSERT INTO Menu
VALUES
	(4,'Menu 4','images/sushi/sushi1.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.',44,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.'),
	(5,'Menu 5','images/sushi/sushi0.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.',55,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.'),
	(6,'Menu 6','images/sushi/sushi2.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.',66,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.')

select* from menu

UPDATE Menu
Set title = 'Menu 2'
where id = 3

CREATE TABLE Infor(
	address varchar(255),
	tel varchar(11),
	email varchar(255),
)

INSERT INTO Infor
VALUES
	('New York NY','12345','your-mail@gmail.com')

SELECT [address], tel, email
FROM Infor

CREATE TABLE Schedule(
	[day] varchar(10),
	[time] varchar(15)
)
INSERT INTO Schedule
VALUES 
	('Monday','11-22'),
	('Tuesday','11-22'),
	('Wednesday','11-22'),
	('Thursday','11-22'),
	('Friday','11-22'),
	('Saturday','11-22')

SELECT* FROM Schedule

SELECT*
FROM (
		select ROW_NUMBER() over (order by ID asc) as rowNumber, *
		from Menu
	) as x
WHERE rowNumber between 1 and 2

SELECT COUNT(id) FROM Menu

CREATE TABLE [View]
(
	[view] int
)
INSERT INTO [View]
VALUES (0)

UPDATE [View]
SET [view] = ( (SELECT* from [View] ) +1)
SELECT* from [View]

